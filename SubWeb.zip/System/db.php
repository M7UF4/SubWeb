<?php
$con = mysqli_connect("localhost","subweb","master","db_subweb");

if (mysqli_connect_errno())
{
	echo "Failed to connect to Database: " .mysqli_connect_error();
}
?>	
