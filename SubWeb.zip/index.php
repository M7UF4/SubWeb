<!-- Header content box -->
<?php 
$title='Index';
$migas='#Index|index.php';
include "Public/layouts/menu.php";?>
      
<!-- Body content box -->
<div class="body-box">

    <div class="content-box">
        <div class="content-title">
            SubWeb
        </div>
        <div class="content-slider">
		
        </div>
        <div class="content-zone">
        </div>
    </div>
</div>
        
<!-- Footer content box -->
<?php include "Public/layouts/footer.php";?> 




