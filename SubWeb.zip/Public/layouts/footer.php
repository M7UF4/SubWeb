<?php

?>
        <!-- Footer content box -->
        <div class="footer-box">
            &nbsp;
        </div>
    </body>
</html> 

